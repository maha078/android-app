# Fitness-Android-APP
It is a fitness App designed to help you during your fitness journey.
It was a semester project.
Mainly has 5 features:
1. STEP COUNTER
2. WATER INTAKE
3. BMI CALCULATOR
4. PORTION CONTROL
5. EXCERCISE VIDEOS
